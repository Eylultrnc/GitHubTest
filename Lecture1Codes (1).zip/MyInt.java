
public class MyInt {
	int value;
	MyInt next, prev;
	
	public MyInt( int initial ) {
		this.value = initial;
	}
	
}
